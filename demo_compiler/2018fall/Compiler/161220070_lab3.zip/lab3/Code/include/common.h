#ifndef __COMMON__
#define __COMMON__

#include <iostream>
#include <sstream>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <map>
#include <algorithm>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cstdarg>
#include <cstdio>
#include <cassert>
#include <cstddef>

// #define LEX_DEBUG
// #define YY_DEBUG
#define IR_OPTIMIZE

using namespace std;

#endif
